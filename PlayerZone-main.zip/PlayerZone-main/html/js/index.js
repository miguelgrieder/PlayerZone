function diminuirOPACIDADE() {
    document.getElementById("playerZoneINDEX_ID").style.opacity = "1"
}

function aumentarOPACIDADE() {
    document.getElementById("playerZoneINDEX_ID").style.opacity = "0.6"
}